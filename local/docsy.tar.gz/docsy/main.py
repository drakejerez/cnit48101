def main():
    print("Hello from template!")


if __name__ == "__main__":
    main()
