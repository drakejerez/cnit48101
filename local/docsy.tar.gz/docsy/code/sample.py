class MyClass:
    """A simple example class"""
    i = 12345

    @staticmethod
    def f():
        return 'hello world'
