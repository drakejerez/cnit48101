Lab 3: Docker Documentation
============================

This page documents the Docker images used for CNIT481 Lab 3. The Docker setup automates the building and serving of Sphinx documentation using Docsy.

Pulling the Containers
----------------------

Images are available from DockerHub at ``jerezdrake649/cnit480`` with the following tags:

* ``v2.0.0`` or ``latest`` - Multi-stage build with nginx (current version)
* ``v1.0.0`` - Single container with Python http.server

To pull the containers, use one of the following commands:

.. prompt:: bash $

    # Pull the latest version (v2.0.0)
    docker pull jerezdrake649/cnit480:latest
    
    # Pull specific versions
    docker pull jerezdrake649/cnit480:v2.0.0
    docker pull jerezdrake649/cnit480:v1.0.0

Running the Containers
----------------------

To run the latest version on port 8080:

.. prompt:: bash $

    docker run -p 8080:8080 jerezdrake649/cnit480:latest

To run the older version (v1.0.0) on port 8000:

.. prompt:: bash $

    docker run -p 8000:8000 jerezdrake649/cnit480:v1.0.0

Current Version (v2.0.0)
------------------------

The current version uses a multi-stage build pattern with two main stages:

1. **Base stage** - Builds the documentation
2. **Serve stage** - Serves the built documentation using nginx

Here is the complete Dockerfile for the current version:

.. literalinclude:: ../../../code/docker/Dockerfile
   :language: dockerfile
   :linenos:
   :caption: Current Dockerfile (v2.0.0)

Key Components:

* **Lines 1-3**: First container builds from Python base image
* **Lines 7-8**: Installs git and clones the docsy repository
* **Lines 12-25**: Installs Python dependencies and the docsy package
* **Lines 27-29**: Builds the HTML documentation
* **Lines 33-35**: Second container based on nginx for serving
* **Lines 36**: Copies built HTML from the first stage
* **Lines 39-45**: Creates nginx cache directories
* **Lines 48-49**: Updates nginx to listen on port 8080
* **Line 51**: Exposes port 8080 for web access

Old Version (v1.0.0)
--------------------

The older version uses a single container approach with Python's built-in http.server:

.. literalinclude:: ../../../code/docker/Dockerfile.old
   :language: dockerfile
   :linenos:
   :caption: Old Dockerfile (v1.0.0)

Key Components:

* **Lines 1-5**: Single Python container with code copied into it
* **Lines 7-21**: Creates virtual environment and installs dependencies
* **Lines 23-26**: Builds the HTML documentation
* **Line 29**: Exposes port 8000
* **Line 30**: Uses Python's http.server to serve files

