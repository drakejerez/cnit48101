#######
Authors
#######

Maintainers
-----------

* CYAN Lab, Purdue University,`https://cyanlab.org`_.
* Deepak Nadig, Purdue University, `https://web.ics.purdue.edu/~nadig/`_.

.. _https://cyanlab.org: https://cyanlab.org
.. _https://web.ics.purdue.edu/~nadig/: http://web.ics.purdue.edu/~nadig/


Contributors
------------

Lab 3 Group
-----------

* Drake Jerez - `djerez@purdue.edu`_
* Luis Soler - `solerl@purdue.edu`_
* Sam Reeves - `reeves51@purdue.edu`_

.. _djerez@purdue.edu: mailto:djerez@purdue.edu
.. _solerl@purdue.edu: mailto:solerl@purdue.edu
.. _reeves51@purdue.edu: mailto:reeves51@purdue.edu

