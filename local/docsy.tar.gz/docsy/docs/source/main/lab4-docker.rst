Lab 4: Docker Documentation Builder
====================================

This page documents the Docker Compose setup for building and serving Sphinx documentation.

Dockerfile
----------

The Dockerfile builds a Python-based container with Sphinx and all documentation dependencies:

.. literalinclude:: ../lab4-real/Dockerfile
   :language: dockerfile
   :linenos:
   :caption: Documentation Builder Dockerfile

Docker Compose Configuration
----------------------------

The main compose file defines services for building and serving documentation:

.. literalinclude:: ../lab4-real/docker-compose.yml
   :language: yaml
   :linenos:
   :caption: Docker Compose Configuration

Services include:
- **builder**: Builds the Sphinx documentation
- **web**: Serves documentation using nginx (prod profile)
- **dev**: Development server with auto-reload (dev profile)
- **dozzle**: Container log viewer (obs profile)
- **cadvisor**: Container metrics (obs profile)

Override Configuration
----------------------

Optional override file for custom port and volume settings:

.. literalinclude:: ../lab4-real/docker-compose.override.yml
   :language: yaml
   :linenos:
   :caption: Docker Compose Override

Makefile
--------

The Makefile provides convenient commands for managing services:

.. literalinclude:: ../lab4-real/Makefile
   :language: makefile
   :linenos:
   :caption: Makefile Commands

Running Services
----------------

Build and start all services:

.. prompt:: bash $

    make prod

Start development server with auto-reload:

.. prompt:: bash $

    make dev

Start with observability tools (Dozzle and cAdvisor):

.. prompt:: bash $

    make obs

Accessing the Site
------------------

After running ``make prod``, access the documentation at:

- **Production**: http://localhost:8080 (or port specified in .env)
- **Development**: http://localhost:8000 (when using ``make dev``)

Observability
-------------

When using the ``obs`` profile, access monitoring tools:

- **Dozzle** (logs): http://localhost:9000
- **cAdvisor** (metrics): http://localhost:9100

Profile Changes
---------------

Use profiles to control which services start:

- ``--profile prod``: Starts web service (nginx)
- ``--profile dev``: Starts development server
- ``--profile obs``: Starts observability tools (dozzle, cadvisor)

Combine profiles as needed:

.. prompt:: bash $

    docker compose --profile prod --profile obs up
