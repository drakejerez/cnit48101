Lab 4: Docker Web Application
==============================

This page documents the Docker setup for CNIT481 Lab 4, which demonstrates a Flask web application with Redis caching.

Overview
--------

Lab 4 implements a simple Flask web application that uses Redis for session management and includes an external API integration for weather data. The application is containerized using Docker Compose, allowing the Flask app and Redis service to run together.

Dockerfile
----------

The Dockerfile builds a Python-based container that runs the Flask application:

.. literalinclude:: ../lab4/Dockerfile
   :language: dockerfile
   :linenos:
   :caption: Lab 4 Dockerfile

**Key Components:**

* **Base Image**: Uses Python 3.10 Alpine for a lightweight container
* **Dependencies**: Installs system libraries (gcc, musl-dev, linux-headers) needed for Python packages
* **Application Setup**: Copies requirements and installs Python dependencies
* **Runtime**: Exposes port 5000 and runs Flask in debug mode

Application (app.py)
--------------------

The Flask application provides two endpoints: a simple hit counter and a weather API integration:

.. literalinclude:: ../lab4/app.py
   :language: python
   :linenos:
   :caption: Lab 4 Flask Application

**Key Components:**

* **Redis Integration**: Uses Redis to maintain a hit counter across requests
* **Root Endpoint** (``/``): Displays a greeting with an incrementing hit count
* **Weather Endpoint** (``/weather``): Fetches current temperature data for Purdue from OpenWeatherMap API

Docker Compose Configuration
-----------------------------

The application uses Docker Compose to orchestrate multiple containers. The main compose file includes an infrastructure configuration:

.. literalinclude:: ../lab4/compose.yaml
   :language: yaml
   :linenos:
   :caption: Lab 4 Docker Compose Configuration

**Key Components:**

* **Service Definition**: Defines the web service that builds from the current directory
* **Port Mapping**: Maps host port 8000 to container port 5000
* **Development Mode**: Enables file watching with sync for live code updates

Infrastructure Configuration
----------------------------

The infrastructure file defines the Redis service used for caching:

.. literalinclude:: ../lab4/infra.yaml
   :language: yaml
   :linenos:
   :caption: Lab 4 Infrastructure Configuration

**Key Components:**

* **Redis Service**: Defines the Redis container using the Alpine image

