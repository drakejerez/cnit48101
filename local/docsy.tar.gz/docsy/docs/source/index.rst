.. CYAN Lab documentation master file, created by
   sphinx-quickstart.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Docsy!
===========================

.. raw:: latex

   \part{Documentation}

.. toctree::
   :maxdepth: 2
   :caption: Documentation

   main/get-started
   main/add-code
   main/lab3-docker
   main/lab4-docker
   main/authors
   main/changelog


.. Indices and tables
.. ==================
.. 
.. * :ref:`genindex`
.. * :ref:`modindex`
.. * :ref:`search`
